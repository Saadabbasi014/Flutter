package com.isdp.database

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
