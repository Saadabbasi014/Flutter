class TodoModel {
  int? id;
  String? task;
  String? description;
  bool? status;

  TodoModel({this.id, this.task, this.description, this.status});
}
