class AppRoutes {
  static const String initialRoute = '/';
  static const String addTodo = '/add_todo';
}
